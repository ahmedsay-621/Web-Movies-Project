import fresh_tomatoes
import media

#creating new inistance(avater) from class Movie
avatar=media.Movie("avatar",
                   "A paraplegic marine dispatched to the moon Pandora on a unique mission ",
                   "https://orig00.deviantart.net/6bde/f/2011/338/c/4/avatar_2_poster_by_paulrom-d4i67c8.jpg",
                   "https://www.youtube.com/watch?v=GeYTUVzItg4")
                   #this is initialization for class avatar
#creating new inistance(avenger2017)from class Movie
avenger2017=media.Movie("avenger2017",
                        "Infinity War Part 2. Upcoming Spider-Man: Homecoming. Oct 17, 2017. ",
                        "https://cpb-us-e1.wpmucdn.com/sites.psu.edu/dist/e/40386/files/2016/03/ironman_marvel.jpg",
                        "https://www.youtube.com/watch?v=6ZfuNTqbHE8")
                        #this is initialization for class iron man
#creating new inistance(avengers) from class Movie
avengers=media.Movie("avengers trailor 2",
                     "protect the world from threats toolargefor any one hero to handle",
                     "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSgrEWDbqrkgQ0geU1dLstSsZ4Ip-WMYbuX2MLLTGtXTzMQHiKXow",
                     "https://www.youtube.com/watch?v=KVQ9Bg920kU")
                     #this is initialization for class avengers
#creating new inistance(avennger3) from class Movie
avennger3=media.Movie("avennger 3",
                      "Infinity War will be released on April 27, 2018",
                      "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQbb0gMDziMDudC66YzJm8bZi1NnKs7wcywn-nE5UNRroyieiucNQ",
                      "https://www.youtube.com/watch?v=KU2APpDcTjI")
                      #this is initialization for class marvel2
#creating new inistance(marvel1)from class Movie
marvel1=media.Movie("marvel trailor 1",
                    "Infinity War will be released ",
                    "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR6tkbmJDUB3lwHeAnmrOJFaMH--yIg1ojQvLP52Av4S-CGAsPQvA ",
                    "https://www.youtube.com/watch?v=HpX1mDEw1gk")
                    #this is initialization for class marvel1
#creating new inistance(Race) from class Movie

Race=media.Movie("Race",
                 "Flash and Superman arrive at JLA headquarters tofind two aliens who have somehow managed to capture",
                 "https://fsmedia.imgix.net/e5/e1/10/81/61e5/4a24/b653/cf84f20e1330/4480820-p00001jpg.jpeg?auto=format%2Ccompress&w=700",
                 "https://www.youtube.com/watch?v=b9V3Pj47x4c")
                 #this is initialization for class marvel1




movies=[avatar,avenger2017,avengers,avennger3,marvel1,Race]
fresh_tomatoes.open_movies_page(movies)

        
    
    
